"""Module entry point."""

from dpc_authenticator import auth

auth.main()
