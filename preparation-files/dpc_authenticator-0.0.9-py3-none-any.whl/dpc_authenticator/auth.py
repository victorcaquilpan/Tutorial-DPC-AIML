"""dpc authentication module."""

import json
import os
import shutil
import subprocess  # nosec - reason: have applied bandit suggestions.
from pathlib import Path

import requests
from google_auth_oauthlib.flow import InstalledAppFlow

# NB: use backport for users with python < 3.7
from importlib_resources import open_text


def _client_secret_str() -> str:
    with open_text("dpc_authenticator", "client_secret.json") as config_file:
        return config_file.read()


def main() -> None:
    """Entry point into the authenication application."""
    print("\n*** AIML - dpc authenicator ***\n")

    if shutil.which("kubectl") is None:
        print(
            "To connect to the dpc cluster you need `kubectl`.\n\nSee: "
            "https://kubernetes.io/docs/tasks/tools/install-kubectl/ for "
            "details on how to get rollin'\n"
        )
        exit(1)

    client_config = json.loads(_client_secret_str())
    flow = InstalledAppFlow.from_client_config(
        client_config,
        scopes=[
            "https://www.googleapis.com/auth/devstorage.read_only",
            "https://www.googleapis.com/auth/userinfo.email",
            "https://www.googleapis.com/auth/userinfo.profile",
            "openid",
        ],
    )
    credentials = flow.run_local_server()
    session = flow.authorized_session()
    profile_info = session.get("https://www.googleapis.com/userinfo/v2/me").json()

    ca_pem = requests.get(
        "https://www.googleapis.com/storage/v1/b/aiml-dpc-cluster/o/ca.crt",
        params={"access_token": credentials.token, "alt": "media"},
    )
    if ca_pem.status_code == 401:
        raise SystemError("Unauthorized access to k8s auth cert.")

    # Stash the PEM file in a dpc authentication directory under the user's
    # home directory.
    config_dir = os.path.join(str(Path.home()), ".dpc-authenticator")
    os.makedirs(config_dir, exist_ok=True)
    pem_file_path = os.path.join(config_dir, "ca.pem")
    with open(pem_file_path, "wb") as f:
        f.write(ca_pem.content)

    # NB: raw string on the cert authority as windows paths are rendered
    # NB: with double slashes via the string interpolation formatter, which
    # NB: naturally breaks a kubectl's path parsing (i.e. golang can
    # NB: handle any path without needing to escape things like python).
    # nosec
    set_cluster_result = subprocess.check_output(
        args=[
            "kubectl",
            "config",
            "set-cluster",
            "dpc",
            "--server=https://10.31.100.110:6443",
            r"--certificate-authority=" + pem_file_path,
            "--embed-certs",
        ],
        shell=False,  # nosec - reason: minized risk with shell=False
    )

    print("")
    print(set_cluster_result.decode("utf-8"))

    set_credentials_result = subprocess.check_output(
        args=[
            "kubectl",
            "config",
            "set-credentials",
            f'{profile_info["email"]}',
            "--auth-provider=oidc",
            "--auth-provider-arg=idp-issuer-url=https://accounts.google.com",
            f"--auth-provider-arg=client-id={credentials.client_id}",
            f"--auth-provider-arg=client-secret={credentials.client_secret}",
            f"--auth-provider-arg=refresh-token={credentials.refresh_token}",
            f"--auth-provider-arg=id-token={credentials.id_token}",
        ],
        shell=False,  # nosec - reason: minized risk with shell=False
    )
    print(set_credentials_result.decode("utf-8"))

    set_context_result = subprocess.check_output(
        args=[
            "kubectl",
            "config",
            "set-context",
            "dpc",
            "--cluster=dpc",
            "--namespace=default",
            f'--user={profile_info["email"]}',
        ],
        shell=False,  # nosec - reason: minized risk with shell=False
    )
    print(set_context_result.decode("utf-8"))

    use_context_result = subprocess.check_output(
        args=["kubectl", "config", "use-context", "dpc"],
        shell=False,  # nosec - reason: minized risk with shell=False
    )
    print(use_context_result.decode("utf-8"))

    exit(0)


if __name__ == "__main__":
    main()
