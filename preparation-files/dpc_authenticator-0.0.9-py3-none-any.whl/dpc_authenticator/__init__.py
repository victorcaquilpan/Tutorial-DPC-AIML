"""Ensure that we're using the correct versions of things."""

import logging
import os
import sys

# Make sure that we are running on Python 3.7 or later.
if sys.version_info < (3, 7):
    raise RuntimeError("The dpc-authenticator requires Python 3.7 or later")

if os.environ.get("MODEL_DEBUG"):
    LEVEL = logging.DEBUG
else:
    LEVEL = logging.INFO

logging.basicConfig(
    format="%(asctime)s - %(levelname)s - %(name)s - %(message)s", level=LEVEL
)
